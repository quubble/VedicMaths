# Vedic_Maths_Tutorial
Vedic Maths Tutorial: Android App to provide Vedic Mathematics Tutorial to people.

The app is developed to provide people with basic addition, subtraction, multiplication, division techniques and also various interesting facts about vedic mathematics.

To execute the project,on desktop, you just need to import the code in IDE you want (eclipse recommended) and then run using the simulator.

To execute the project on your mobile phone, you need to copy the file : "Vedic Math's Tutorial/bin/VedicMath.apk" to your phone and run the apk file on your phone.
